void initFps();
int loadFps(long end_ticks);
int finishLoadFps();
void quitFPS();

void drawFps();
SPRITE FpsTextSprite;

#define FPS_TEXT_TEXTURE "fps_str.png"
