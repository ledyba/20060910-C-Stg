int initMusic();
int loadMusic(char* name);
int playMusic(long start_sample,long fade_msec);

