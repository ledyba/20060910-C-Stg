void srnd(uint seed);
uint rnd();
