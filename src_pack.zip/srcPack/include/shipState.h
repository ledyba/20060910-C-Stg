void initShipState();
void drawShipState();
void drawShipGauge();
void drawShipBonusPowerGauge();
void drawShipAttractPowerGauge();
void drawShipLifeGauge();
void drawFoeOrBossLifeGauge();
void setLifeGaugeTarget(int* shield);
/*�X�R�A��\��*/
void drawScore();
